'use client'
import { useRef, useState, useEffect, type RefObject } from 'react'
import { SITE, ROLES, STATS } from '@/data/portfolio'
import { useTypewriter, useCountUp, useInView } from '@/hooks/useInView'

function ParticleField() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const setSize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    setSize()
    window.addEventListener('resize', setSize)

    const particles: { x: number; y: number; vx: number; vy: number; size: number; alpha: number }[] = []
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.4 + 0.1,
      })
    }

    let raf: number
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0) p.x = canvas.width
        if (p.x > canvas.width) p.x = 0
        if (p.y < 0) p.y = canvas.height
        if (p.y > canvas.height) p.y = 0

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(0,200,255,${p.alpha})`
        ctx.fill()
      }
      raf = requestAnimationFrame(animate)
    }
    animate()

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', setSize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{ position: 'absolute', inset: 0, zIndex: 1, pointerEvents: 'none' }}
    />
  )
}

function StatCard({ value, label, suffix, active }: { value: number; label: string; suffix?: string; active: boolean }) {
  const count = useCountUp(value, active)
  return (
    <div className="stat-card">
      <div className="stat-number" aria-label={`${value}${suffix || ''} ${label}`}>
        {count}{suffix || ''}
      </div>
      <div className="stat-label">{label}</div>
    </div>
  )
}

export default function HeroSection() {
  const displayed = useTypewriter(ROLES)
  const { ref: statsRef, inView } = useInView(0.3)

  return (
    <section
      id="home"
      aria-label="Hero"
      style={{
        position: 'relative',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        overflow: 'hidden',
      }}
    >
      {/* Video background */}
      <video
        className="hero-video-bg"
        src={SITE.heroVideo}
        autoPlay
        muted
        loop
        playsInline
        aria-hidden="true"
        preload="none"
      />

      {/* Overlays */}
      <div className="hero-overlay" aria-hidden="true" />
      <div className="hero-grid" aria-hidden="true" />
      <div className="scan-line" aria-hidden="true" />
      <ParticleField />

      {/* Aurora orbs */}
      <div className="aurora" aria-hidden="true">
        <div
          className="aurora-orb"
          style={{ width: 600, height: 600, top: '-200px', right: '-100px', background: 'var(--cyan)' }}
        />
        <div
          className="aurora-orb"
          style={{ width: 400, height: 400, bottom: '-100px', left: '-100px', background: 'var(--violet)' }}
        />
      </div>

      {/* Content */}
      <div
        className="container"
        style={{ position: 'relative', zIndex: 3, paddingTop: 120, paddingBottom: 80 }}
      >
        {/* Availability pill */}
        <div style={{ marginBottom: 28, animation: 'fadeUp 0.5s ease 0.1s both' }}>
          <div className="status-pill">
            <span className="status-dot" aria-hidden="true" />
            {SITE.availability}
          </div>
        </div>

        {/* Location */}
        <div style={{ animation: 'fadeUp 0.5s ease 0.2s both' }}>
          <p
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 12,
              letterSpacing: 3,
              color: 'var(--text-3)',
              textTransform: 'uppercase',
              marginBottom: 14,
            }}
          >
            {SITE.location}
          </p>
        </div>

        {/* Name */}
        <div style={{ animation: 'fadeUp 0.5s ease 0.3s both', marginBottom: 12 }}>
          <h1
            style={{
              fontSize: 'clamp(40px, 7.5vw, 80px)',
              fontWeight: 700,
              color: 'var(--text-1)',
              lineHeight: 1.02,
            }}
          >
            {SITE.name}
          </h1>
        </div>

        {/* Typewriter role */}
        <div
          style={{ animation: 'fadeUp 0.5s ease 0.4s both', marginBottom: 28 }}
          aria-live="polite"
          aria-label={`Currently: ${displayed}`}
        >
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 'clamp(16px, 2.5vw, 26px)',
              color: 'var(--cyan)',
              display: 'flex',
              alignItems: 'center',
              gap: 2,
              height: 40,
            }}
          >
            {displayed}
            <span className="cursor-blink" style={{ color: 'var(--cyan)', fontWeight: 300 }}>|</span>
          </div>
        </div>

        {/* Bio */}
        <div style={{ animation: 'fadeUp 0.5s ease 0.5s both', marginBottom: 44 }}>
          <p
            style={{
              fontSize: 16,
              color: 'var(--text-2)',
              lineHeight: 1.85,
              maxWidth: 560,
            }}
          >
            {SITE.bio}
          </p>
        </div>

        {/* CTAs */}
        <div
          style={{
            animation: 'fadeUp 0.5s ease 0.6s both',
            display: 'flex',
            flexWrap: 'wrap',
            gap: 14,
            marginBottom: 64,
          }}
        >
          <a href="#zyntra" className="btn-primary">
            View Featured Project →
          </a>
          <a href="#projects" className="btn-outline">
            All Projects
          </a>
          <a href="#contact" className="btn-outline" style={{ borderColor: 'var(--cyan-border)', color: 'var(--cyan)' }}>
            Let&apos;s Connect
          </a>
        </div>

        {/* Stats */}
        <div
          ref={statsRef as unknown as RefObject<HTMLDivElement>}
          style={{
            animation: 'fadeUp 0.5s ease 0.75s both',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
            gap: 12,
            maxWidth: 580,
          }}
          aria-label="Portfolio statistics"
        >
          {STATS.map(s => (
            <StatCard key={s.label} {...s} active={inView} />
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        aria-hidden="true"
        style={{
          position: 'absolute',
          bottom: 32,
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 3,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 8,
          animation: 'fadeUp 0.5s ease 1.2s both',
        }}
      >
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: 3, color: 'var(--text-3)', textTransform: 'uppercase' }}>
          Scroll
        </div>
        <div style={{ width: 1, height: 40, background: 'linear-gradient(to bottom, var(--cyan), transparent)', animation: 'float 2s ease-in-out infinite' }} />
      </div>
    </section>
  )
}
